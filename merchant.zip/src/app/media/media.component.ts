import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-media',
  templateUrl: './media.component.html',
  styleUrls: ['./media.component.scss']
})
export class MediaComponent implements OnInit {
  video='../../assets/video/VideoOfHotelLounge.mp4';
  image = '../../assets/img/photo.jpg';
  show = false;
  showcontent = true;
  showvideo: Boolean;
showMore1: Boolean;
showimage: Boolean;
showMore2: Boolean;
uploadForm: FormGroup;
imageSrc: string;
constructor(private fb: FormBuilder) {
  this.uploadForm = this.fb.group({
    Title: ['', Validators.required],
    Description : ['', Validators.required],
    storeCategory: ['', Validators.required],
    file: ['', [Validators.required]],
    fileSource: ['', [Validators.required]],
  });  
}

onFileChange(event) {
  const reader = new FileReader();
  if (event.target.files && event.target.files.length) {
    const [file] = event.target.files;
    reader.readAsDataURL(file);
    reader.onload = ( ) => {
      this.imageSrc = reader.result as string;
      this.uploadForm.patchValue ({
        fileSource: reader.result,
      });
    };
  }
}
show1(){
 this.show = true;
 this.showcontent = false;
}
submitForm(uploadForm){
  console.log(this.uploadForm.value);
}
ngOnInit() {
  this.uploadForm = new FormGroup({
    Title : new FormControl("", Validators.required),
    Description : new FormControl("", Validators.required),
    file : new FormControl("", Validators.required),
    fileSource : new FormControl("", Validators.required),
  });
}

}
