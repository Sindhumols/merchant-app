import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-landing-page',
  templateUrl: './merchant-landing-page.component.html',
  styleUrls: ['./merchant-landing-page.component.scss']
})
export class MerchantLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
