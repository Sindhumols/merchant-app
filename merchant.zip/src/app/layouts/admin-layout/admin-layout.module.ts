import { OutdatedCouponsIndivualComponent } from './../../outdated-coupons-indivual/outdated-coupons-indivual.component';
import { ActiveCouponsIndivualComponent } from './../../active-coupons-indivual/active-coupons-indivual.component';
import { OutdatedCouponsComponent } from './../../outdated-coupons/outdated-coupons.component';
import { ActiveCouponsComponent } from './../../active-coupons/active-coupons.component';
import { MercahntDashboardModule } from './../../merchant-dashboard/merchant-dashboard.module';
import { MediaComponent } from './../../media/media.component';
import { UserCouponsComponent } from './../../user-coupons/user-coupons.component';
import { SubscriptionDetailsComponent } from './../../subscription-details/subscription-details.component';
import { FaqComponent } from './../../faq/faq.component';
import { HistoryComponent } from './../../history/history.component';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminLayoutRoutes } from './admin-layout.routing';

import {
  MatButtonModule,
  MatInputModule,
  MatRippleModule,
  MatFormFieldModule,
  MatTooltipModule,
  MatSelectModule
} from '@angular/material';
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatRippleModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
    MercahntDashboardModule
  ],
  declarations: [
    UserCouponsComponent,
    MediaComponent,
    HistoryComponent,
    SubscriptionDetailsComponent,
    FaqComponent,
    ActiveCouponsComponent,
    OutdatedCouponsComponent,
    ActiveCouponsIndivualComponent,
    OutdatedCouponsIndivualComponent,
  ]
})

export class AdminLayoutModule {}
